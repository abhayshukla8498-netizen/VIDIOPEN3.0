package com.example.data.database

import androidx.room.*
import com.example.data.model.TransferHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferHistoryDao {
    @Query("SELECT * FROM transfer_history ORDER BY transferTime DESC")
    fun getAllHistory(): Flow<List<TransferHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: TransferHistoryEntity): Long

    @Update
    suspend fun updateHistory(history: TransferHistoryEntity)

    @Query("DELETE FROM transfer_history")
    suspend fun clearHistory()
}
