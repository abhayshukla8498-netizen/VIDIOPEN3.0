package com.example.data.model

data class ActiveTransfer(
    val id: String,
    val fileName: String,
    val fileSize: Long,
    val bytesTransferred: Long,
    val isIncoming: Boolean,
    val status: TransferStatus,
    val speedBytesPerSecond: Long = 0,
    val remainingTimeSeconds: Long = 0,
    val isPaused: Boolean = false
)

enum class TransferStatus {
    PENDING,
    IN_PROGRESS,
    PAUSED,
    SUCCESS,
    FAILED,
    CANCELLED
}
