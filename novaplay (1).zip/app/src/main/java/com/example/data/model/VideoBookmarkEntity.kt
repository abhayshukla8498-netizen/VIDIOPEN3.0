package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "video_bookmarks")
data class VideoBookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val videoId: String,
    val videoName: String,
    val timestampMs: Long,
    val bookmarkName: String?,
    val dateCreated: Long = System.currentTimeMillis(),
    val thumbnailPath: String? = null
)
