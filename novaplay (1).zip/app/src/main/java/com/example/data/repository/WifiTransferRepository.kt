package com.example.data.repository

import android.content.Context
import android.net.wifi.WifiManager
import com.example.data.database.AppDatabase
import com.example.data.model.ActiveTransfer
import com.example.data.model.ConnectionRequest
import com.example.data.model.TransferHistoryEntity
import com.example.data.model.TransferStatus
import com.example.service.WifiTransferServer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.TimeUnit

class WifiTransferRepository(private val database: AppDatabase) {

    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var server: WifiTransferServer? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverIp = MutableStateFlow<String?>(null)
    val serverIp: StateFlow<String?> = _serverIp.asStateFlow()

    private val _serverPort = MutableStateFlow(8080)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    private val _sessionCode = MutableStateFlow<String?>(null)
    val sessionCode: StateFlow<String?> = _sessionCode.asStateFlow()

    private val _connectionRequest = MutableStateFlow<ConnectionRequest?>(null)
    val connectionRequest: StateFlow<ConnectionRequest?> = _connectionRequest.asStateFlow()

    private val _activeTransfers = MutableStateFlow<List<ActiveTransfer>>(emptyList())
    val activeTransfers: StateFlow<List<ActiveTransfer>> = _activeTransfers.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<String>>(emptyList())
    val discoveredDevices: StateFlow<List<String>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val transferHistory = database.transferHistoryDao().getAllHistory()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.MINUTES) // support massive files
        .writeTimeout(120, TimeUnit.MINUTES)
        .build()

    fun startServer(context: Context) {
        if (_isServerRunning.value) return

        val ip = getLocalWifiIpAddress(context) ?: "127.0.0.1"
        val port = 8080
        _serverIp.value = ip
        _serverPort.value = port

        server = WifiTransferServer(
            context = context,
            port = port,
            onConnectionRequest = { ipAddress, code, onResponse ->
                _connectionRequest.value = ConnectionRequest(
                    deviceIp = ipAddress,
                    deviceName = "Remote Device (IP: $ipAddress)",
                    sessionCode = code,
                    onResponse = { approved ->
                        onResponse(approved)
                        _connectionRequest.value = null
                    }
                )
            },
            onTransferUpdated = { transfer ->
                val currentList = _activeTransfers.value.toMutableList()
                val index = currentList.indexOfFirst { it.id == transfer.id }
                if (index != -1) {
                    currentList[index] = transfer
                } else {
                    currentList.add(transfer)
                }
                _activeTransfers.value = currentList
            },
            onTransferSaved = { name, size, isIncoming, success ->
                repositoryScope.launch {
                    val statusStr = if (success) "Completed" else "Cancelled/Failed"
                    database.transferHistoryDao().insertHistory(
                        TransferHistoryEntity(
                            fileName = name,
                            fileSize = size,
                            deviceName = if (isIncoming) "Web Client" else "Device",
                            status = statusStr,
                            isIncoming = isIncoming
                        )
                    )
                }
            }
        )

        server?.start()
        _sessionCode.value = server?.sessionCode
        _isServerRunning.value = true
        Timber.d("WifiTransferRepository: Server started at http://$ip:$port code: ${_sessionCode.value}")
    }

    fun stopServer() {
        if (!_isServerRunning.value) return
        server?.stop()
        server = null
        _isServerRunning.value = false
        _serverIp.value = null
        _sessionCode.value = null
        _connectionRequest.value = null
        _activeTransfers.value = emptyList()
        Timber.d("WifiTransferRepository: Server stopped")
    }

    fun approveConnection(approved: Boolean) {
        val request = _connectionRequest.value
        if (request != null) {
            request.onResponse(approved)
        }
    }

    fun cancelTransfer(id: String) {
        server?.cancelTransfer(id)
        // Also cancel native client sends
        val currentList = _activeTransfers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index != -1) {
            currentList[index] = currentList[index].copy(status = TransferStatus.CANCELLED)
            _activeTransfers.value = currentList
        }
    }

    suspend fun clearHistory() {
        database.transferHistoryDao().clearHistory()
    }

    // Android-to-Android native sender implementation
    suspend fun sendFilesNatively(
        targetIp: String,
        targetPort: Int,
        files: List<File>,
        targetSessionCode: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // 1. Send auth code request to target server
            val authUrl = "http://$targetIp:$targetPort/api/auth?code=$targetSessionCode"
            val authRequest = Request.Builder()
                .url(authUrl)
                .post(RequestBody.create(null, ByteArray(0)))
                .build()

            val authResponse = okHttpClient.newCall(authRequest).execute()
            if (!authResponse.isSuccessful) {
                return@withContext Result.failure(Exception("Rejected by remote device: ${authResponse.message}"))
            }

            // 2. Poll/wait for remote approval (up to 30s)
            var approved = false
            for (i in 1..15) {
                delay(2000)
                val statusUrl = "http://$targetIp:$targetPort/api/auth/status"
                val statusRequest = Request.Builder().url(statusUrl).build()
                val statusResponse = okHttpClient.newCall(statusRequest).execute()
                if (statusResponse.isSuccessful) {
                    val body = statusResponse.body?.string() ?: ""
                    if (body.contains("\"status\":\"approved\"")) {
                        approved = true
                        break
                    }
                }
            }

            if (!approved) {
                return@withContext Result.failure(Exception("Connection approval timed out or declined."))
            }

            // 3. Upload files sequentially
            for (file in files) {
                val uploadUrl = "http://$targetIp:$targetPort/api/upload?filename=${java.net.URLEncoder.encode(file.name, "UTF-8")}"
                val transferId = file.absolutePath

                val activeTransfer = ActiveTransfer(
                    id = transferId,
                    fileName = file.name,
                    fileSize = file.length(),
                    bytesTransferred = 0L,
                    isIncoming = false,
                    status = TransferStatus.IN_PROGRESS
                )
                updateActiveTransfer(activeTransfer)

                val customRequestBody = object : RequestBody() {
                    override fun contentType(): MediaType? = "application/octet-stream".toMediaTypeOrNull()
                    override fun contentLength(): Long = file.length()
                    override fun writeTo(sink: BufferedSink) {
                        val input = FileInputStream(file)
                        val buffer = ByteArray(256 * 1024)
                        var bytesRead: Int
                        var totalBytesWritten = 0L
                        var lastUpdate = System.currentTimeMillis()
                        var lastBytes = 0L

                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            sink.write(buffer, 0, bytesRead)
                            totalBytesWritten += bytesRead

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate >= 500) {
                                val speed = ((totalBytesWritten - lastBytes) * 1000) / (now - lastUpdate)
                                val eta = if (speed > 0) (file.length() - totalBytesWritten) / speed else 0L

                                updateActiveTransfer(
                                    activeTransfer.copy(
                                        bytesTransferred = totalBytesWritten,
                                        speedBytesPerSecond = speed,
                                        remainingTimeSeconds = eta
                                    )
                                )
                                lastUpdate = now
                                lastBytes = totalBytesWritten
                            }
                        }
                        input.close()
                    }
                }

                val uploadRequest = Request.Builder()
                    .url(uploadUrl)
                    .addHeader("Content-Length", file.length().toString())
                    .post(customRequestBody)
                    .build()

                try {
                    val uploadResponse = okHttpClient.newCall(uploadRequest).execute()
                    if (uploadResponse.isSuccessful) {
                        updateActiveTransfer(activeTransfer.copy(bytesTransferred = file.length(), status = TransferStatus.SUCCESS))
                        database.transferHistoryDao().insertHistory(
                            TransferHistoryEntity(
                                fileName = file.name,
                                fileSize = file.length(),
                                deviceName = "Android Peer ($targetIp)",
                                status = "Completed",
                                isIncoming = false
                            )
                        )
                    } else {
                        throw Exception("Server returned error: ${uploadResponse.code}")
                    }
                } catch (e: Exception) {
                    updateActiveTransfer(activeTransfer.copy(status = TransferStatus.FAILED))
                    database.transferHistoryDao().insertHistory(
                        TransferHistoryEntity(
                            fileName = file.name,
                            fileSize = file.length(),
                            deviceName = "Android Peer ($targetIp)",
                            status = "Failed",
                            isIncoming = false
                        )
                    )
                    return@withContext Result.failure(e)
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun updateActiveTransfer(transfer: ActiveTransfer) {
        val currentList = _activeTransfers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == transfer.id }
        if (index != -1) {
            currentList[index] = transfer
        } else {
            currentList.add(transfer)
        }
        _activeTransfers.value = currentList
    }

    fun scanForDevices(context: Context) {
        if (_isScanning.value) return
        _isScanning.value = true
        _discoveredDevices.value = emptyList()

        repositoryScope.launch {
            try {
                val localIp = getLocalWifiIpAddress(context) ?: "127.0.0.1"
                if (localIp == "127.0.0.1" || localIp == "0.0.0.0") {
                    _isScanning.value = false
                    return@launch
                }

                val prefix = localIp.substringBeforeLast(".") + "."
                val foundList = mutableListOf<String>()

                val jobs = mutableListOf<Deferred<String?>>()
                for (i in 1..254) {
                    val targetIp = "$prefix$i"
                    if (targetIp == localIp) continue // skip self
                    val job = async(Dispatchers.IO) {
                        var socket: java.net.Socket? = null
                        try {
                            socket = java.net.Socket()
                            socket.connect(java.net.InetSocketAddress(targetIp, 8080), 250) // 250ms is very safe for local networks
                            targetIp
                        } catch (e: Exception) {
                            null
                        } finally {
                            try {
                                socket?.close()
                            } catch (e: Exception) {
                                // ignore
                            }
                        }
                    }
                    jobs.add(job)
                }

                val results = jobs.awaitAll().filterNotNull()
                _discoveredDevices.value = results
            } catch (e: Exception) {
                Timber.e(e, "Error scanning local subnet")
            } finally {
                _isScanning.value = false
            }
        }
    }

    private fun getLocalWifiIpAddress(context: Context): String? {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipAddress = wm.connectionInfo.ipAddress
        if (ipAddress != 0) {
            return String.format(
                Locale.US,
                "%d.%d.%d.%d",
                ipAddress and 0xff,
                ipAddress shr 8 and 0xff,
                ipAddress shr 16 and 0xff,
                ipAddress shr 24 and 0xff
            )
        }
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error getting IP address")
        }
        return null
    }
}
