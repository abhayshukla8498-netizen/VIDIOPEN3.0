package com.example.domain.usecase

import com.example.data.repository.MediaRepository

class ToggleFavoriteUseCase(private val repository: MediaRepository) {
    suspend operator fun invoke(id: String, isFavorite: Boolean) {
        repository.toggleFavorite(id, isFavorite)
    }
}
