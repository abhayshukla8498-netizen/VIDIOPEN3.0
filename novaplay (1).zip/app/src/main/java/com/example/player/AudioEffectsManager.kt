package com.example.player

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import timber.log.Timber

class AudioEffectsManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("audio_effects_prefs", Context.MODE_PRIVATE)

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: android.media.audiofx.PresetReverb? = null
    private var currentSessionId: Int = 0

    // Properties initialized from SharedPreferences
    var eqEnabled: Boolean
        get() = prefs.getBoolean("eq_enabled", true)
        set(value) {
            prefs.edit().putBoolean("eq_enabled", value).apply()
            initEffectsIfNecessary()
            try {
                equalizer?.enabled = value
                if (value) {
                    applyAllBands()
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable equalizer")
            }
        }

    var selectedPreset: String
        get() = prefs.getString("selected_preset", "Normal") ?: "Normal"
        set(value) {
            prefs.edit().putString("selected_preset", value).apply()
            if (value != "Custom") {
                applyPreset(value)
            }
        }

    var bassBoostEnabled: Boolean
        get() = prefs.getBoolean("bass_boost_enabled", false)
        set(value) {
            prefs.edit().putBoolean("bass_boost_enabled", value).apply()
            initEffectsIfNecessary()
            try {
                bassBoost?.enabled = value
                if (value) {
                    applyBassBoostStrength(bassBoostStrength)
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable bass boost")
            }
        }

    var bassBoostStrength: Int
        get() = prefs.getInt("bass_boost_strength", 0)
        set(value) {
            prefs.edit().putInt("bass_boost_strength", value).apply()
            if (value > 0 && !bassBoostEnabled) {
                bassBoostEnabled = true
            }
            initEffectsIfNecessary()
            applyBassBoostStrength(value)
        }

    var virtualizerEnabled: Boolean
        get() = prefs.getBoolean("virtualizer_enabled", false)
        set(value) {
            prefs.edit().putBoolean("virtualizer_enabled", value).apply()
            initEffectsIfNecessary()
            try {
                virtualizer?.enabled = value
                if (value) {
                    applyVirtualizerStrength(virtualizerStrength)
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable virtualizer")
            }
        }

    var virtualizerStrength: Int
        get() = prefs.getInt("virtualizer_strength", 0)
        set(value) {
            prefs.edit().putInt("virtualizer_strength", value).apply()
            if (value > 0 && !virtualizerEnabled) {
                virtualizerEnabled = true
            }
            initEffectsIfNecessary()
            applyVirtualizerStrength(value)
        }

    var loudnessEnabled: Boolean
        get() = prefs.getBoolean("loudness_enabled", false)
        set(value) {
            prefs.edit().putBoolean("loudness_enabled", value).apply()
            initEffectsIfNecessary()
            try {
                loudnessEnhancer?.enabled = value
                if (value) {
                    applyLoudnessGain(loudnessGain)
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable loudness enhancer")
            }
        }

    var loudnessGain: Float
        get() = prefs.getFloat("loudness_gain", 0f)
        set(value) {
            prefs.edit().putFloat("loudness_gain", value).apply()
            if (value > 0f && !loudnessEnabled) {
                loudnessEnabled = true
            }
            initEffectsIfNecessary()
            applyLoudnessGain(value)
        }

    var reverbPreset: Short
        get() = prefs.getInt("reverb_preset", android.media.audiofx.PresetReverb.PRESET_NONE.toInt()).toShort()
        set(value) {
            prefs.edit().putInt("reverb_preset", value.toInt()).apply()
            initEffectsIfNecessary()
            try {
                presetReverb?.enabled = (value != android.media.audiofx.PresetReverb.PRESET_NONE)
                presetReverb?.preset = value
            } catch (e: Exception) {
                Timber.e(e, "Failed to set reverb preset")
            }
        }

    // Stores 10 virtual band gains in dB (-15 to +15)
    private val _eqBands = IntArray(10) { 0 }
    val eqBands: IntArray get() = _eqBands

    companion object {
        val PRESETS = mapOf(
            "Normal" to intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            "Pop" to intArrayOf(-1, 2, 4, 5, 3, -1, -2, -2, -1, 1),
            "Rock" to intArrayOf(4, 3, -1, -2, -1, 1, 3, 4, 4, 3),
            "Jazz" to intArrayOf(3, 2, 1, 2, -1, -1, 0, 1, 3, 3),
            "Classical" to intArrayOf(3, 2, 2, 1, -1, -1, 0, 2, 3, 3),
            "Dance" to intArrayOf(5, 4, 2, 0, -1, 2, 4, 4, 3, 1),
            "Bass Boost" to intArrayOf(7, 6, 5, 3, 1, 0, 0, 0, 0, 0),
            "Vocal" to intArrayOf(-3, -2, 0, 3, 5, 4, 3, 1, -1, -2),
            "Cinema" to intArrayOf(5, 4, 1, 0, -1, 0, 2, 4, 5, 4),
            "3D Spatial" to intArrayOf(4, 3, 1, 2, 3, 3, 2, 3, 4, 5),
            "EDM Heavy" to intArrayOf(8, 7, 4, 1, -1, 2, 5, 6, 5, 3),
            "Club" to intArrayOf(6, 5, 3, 1, 0, 2, 4, 5, 3, 2)
        )
    }

    init {
        // Load eq bands
        for (i in 0..9) {
            _eqBands[i] = prefs.getInt("eq_band_$i", 0)
        }
    }

    private fun initEffectsIfNecessary() {
        if (currentSessionId > 0 && (equalizer == null || bassBoost == null || virtualizer == null || loudnessEnhancer == null)) {
            onAudioSessionIdChanged(currentSessionId)
        }
    }

    fun onAudioSessionIdChanged(sessionId: Int) {
        if (sessionId <= 0) return
        val isNewSession = sessionId != currentSessionId
        currentSessionId = sessionId

        if (isNewSession) {
            Timber.d("AudioEffectsManager: New audio session ID $sessionId, releasing old effects")
            release()
        }

        if (equalizer == null) {
            try {
                equalizer = Equalizer(0, sessionId).apply {
                    enabled = eqEnabled
                    applyAllBands()
                }
            } catch (e: Exception) {
                Timber.w("Equalizer unavailable on session $sessionId: ${e.message}")
            }
        } else {
            try {
                equalizer?.enabled = eqEnabled
                applyAllBands()
            } catch (e: Exception) {
                Timber.w("Failed to update Equalizer: ${e.message}")
            }
        }

        if (bassBoost == null) {
            try {
                bassBoost = BassBoost(0, sessionId).apply {
                    enabled = bassBoostEnabled
                    if (strengthSupported) {
                        setStrength(bassBoostStrength.coerceIn(0, 1000).toShort())
                    }
                }
            } catch (e: Exception) {
                Timber.w("BassBoost unavailable on session $sessionId: ${e.message}")
            }
        } else {
            try {
                bassBoost?.enabled = bassBoostEnabled
                applyBassBoostStrength(bassBoostStrength)
            } catch (e: Exception) {
                Timber.w("Failed to update BassBoost: ${e.message}")
            }
        }

        if (virtualizer == null) {
            try {
                virtualizer = Virtualizer(0, sessionId).apply {
                    enabled = virtualizerEnabled
                    if (strengthSupported) {
                        setStrength(virtualizerStrength.coerceIn(0, 1000).toShort())
                    }
                }
            } catch (e: Exception) {
                Timber.w("Virtualizer unavailable on session $sessionId: ${e.message}")
            }
        } else {
            try {
                virtualizer?.enabled = virtualizerEnabled
                applyVirtualizerStrength(virtualizerStrength)
            } catch (e: Exception) {
                Timber.w("Failed to update Virtualizer: ${e.message}")
            }
        }

        if (loudnessEnhancer == null) {
            try {
                loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                    enabled = loudnessEnabled
                    setTargetGain((loudnessGain * 100f).toInt())
                }
            } catch (e: Exception) {
                Timber.w("LoudnessEnhancer unavailable on session $sessionId: ${e.message}")
            }
        } else {
            try {
                loudnessEnhancer?.enabled = loudnessEnabled
                applyLoudnessGain(loudnessGain)
            } catch (e: Exception) {
                Timber.w("Failed to update LoudnessEnhancer: ${e.message}")
            }
        }

        if (presetReverb == null) {
            try {
                presetReverb = android.media.audiofx.PresetReverb(0, sessionId).apply {
                    enabled = (reverbPreset != android.media.audiofx.PresetReverb.PRESET_NONE)
                    preset = reverbPreset
                }
            } catch (e: Exception) {
                Timber.w("PresetReverb unavailable on session $sessionId: ${e.message}")
            }
        } else {
            try {
                presetReverb?.enabled = (reverbPreset != android.media.audiofx.PresetReverb.PRESET_NONE)
                presetReverb?.preset = reverbPreset
            } catch (e: Exception) {
                Timber.w("Failed to update PresetReverb: ${e.message}")
            }
        }
    }

    fun setEqBand(bandIndex: Int, gainDb: Int) {
        if (bandIndex in 0..9) {
            _eqBands[bandIndex] = gainDb
            prefs.edit().putInt("eq_band_$bandIndex", gainDb).apply()
            if (!eqEnabled) {
                eqEnabled = true
            } else {
                initEffectsIfNecessary()
                applyAllBands()
            }
        }
    }

    private fun applyPreset(presetName: String) {
        val presetBands = PRESETS[presetName] ?: getCustomPreset(presetName) ?: PRESETS["Normal"]!!
        for (i in 0..9) {
            _eqBands[i] = presetBands[i]
            prefs.edit().putInt("eq_band_$i", presetBands[i]).apply()
        }
        if (!eqEnabled) {
            eqEnabled = true
        } else {
            initEffectsIfNecessary()
            applyAllBands()
        }
    }

    private fun applyAllBands() {
        val eq = equalizer ?: return
        try {
            if (!eqEnabled) return
            val numHardwareBands = eq.numberOfBands.toInt()
            if (numHardwareBands <= 0) return

            val range = eq.bandLevelRange
            val minRange = range[0].toInt()
            val maxRange = range[1].toInt()

            for (hwIndex in 0 until numHardwareBands) {
                val mappedGains = mutableListOf<Int>()
                for (vIndex in 0..9) {
                    val mappedHw = (vIndex * numHardwareBands / 10).coerceIn(0, numHardwareBands - 1)
                    if (mappedHw == hwIndex) {
                        mappedGains.add(_eqBands[vIndex])
                    }
                }
                val avgGain = if (mappedGains.isNotEmpty()) mappedGains.average().toInt() else 0
                val levelmB = (avgGain * 100).coerceIn(minRange, maxRange).toShort()
                eq.setBandLevel(hwIndex.toShort(), levelmB)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply bands to hardware Equalizer")
        }
    }

    private fun applyBassBoostStrength(strength: Int) {
        try {
            val bb = bassBoost ?: return
            if (bb.strengthSupported) {
                bb.setStrength(strength.coerceIn(0, 1000).toShort())
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply BassBoost strength")
        }
    }

    private fun applyVirtualizerStrength(strength: Int) {
        try {
            val virt = virtualizer ?: return
            if (virt.strengthSupported) {
                virt.setStrength(strength.coerceIn(0, 1000).toShort())
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply Virtualizer strength")
        }
    }

    private fun applyLoudnessGain(gainDb: Float) {
        try {
            loudnessEnhancer?.setTargetGain((gainDb * 100f).toInt())
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply LoudnessEnhancer target gain")
        }
    }

    // Custom Presets management
    fun saveCustomPreset(name: String, bands: IntArray) {
        val presetStr = bands.joinToString(",")
        prefs.edit().putString("custom_preset_$name", presetStr).apply()
        
        val existing = getCustomPresetNames().toMutableSet()
        existing.add(name)
        prefs.edit().putStringSet("custom_preset_names", existing).apply()
    }

    fun getCustomPresetNames(): Set<String> {
        return prefs.getStringSet("custom_preset_names", emptySet()) ?: emptySet()
    }

    fun deleteCustomPreset(name: String) {
        prefs.edit().remove("custom_preset_$name").apply()
        val existing = getCustomPresetNames().toMutableSet()
        existing.remove(name)
        prefs.edit().putStringSet("custom_preset_names", existing).apply()
    }

    fun getCustomPreset(name: String): IntArray? {
        val str = prefs.getString("custom_preset_$name", null) ?: return null
        return try {
            str.split(",").map { it.toInt() }.toIntArray()
        } catch (e: Exception) {
            null
        }
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing Equalizer")
        }
        equalizer = null

        try {
            bassBoost?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing BassBoost")
        }
        bassBoost = null

        try {
            virtualizer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing Virtualizer")
        }
        virtualizer = null

        try {
            loudnessEnhancer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing LoudnessEnhancer")
        }
        loudnessEnhancer = null

        try {
            presetReverb?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing PresetReverb")
        }
        presetReverb = null
    }
}
