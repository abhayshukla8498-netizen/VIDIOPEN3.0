package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ScannedSong
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MusicTheme
import com.example.ui.theme.MusicThemeRegistry
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MusicViewModel
import kotlin.math.cos
import kotlin.math.sin

val TShirtIcon: ImageVector
    get() = Icons.Rounded.Style

@Composable
fun MusicPlayerView(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    onCollapse: () -> Unit
) {
    val context = LocalContext.current
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val theme by musicViewModel.currentTheme.collectAsState()
    val customImageUri by musicViewModel.customThemeImageUri.collectAsState()
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()
    val repeatMode by musicViewModel.repeatMode.collectAsState()
    val shuffleEnabled by musicViewModel.shuffleModeEnabled.collectAsState()
    val favoriteSongIds by musicViewModel.favoriteSongIds.collectAsState()
    val playbackSpeed by musicViewModel.playbackSpeed.collectAsState()

    var showAudioSettings by remember { mutableStateOf(false) }
    var showEqualizerSettings by remember { mutableStateOf(false) }
    var initialAudioSettingsTab by remember { mutableStateOf("Audio Tuning") }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showQueueBottomSheet by remember { mutableStateOf(false) }
    var showLyricsOverlay by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showSongInfoDialog by remember { mutableStateOf(false) }

    val song = activeTrack ?: return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("expanded_music_player")
    ) {
        // Background - if custom photo theme is active, render user's photo background
        val effectiveUri = theme.bgImageUri ?: customImageUri
        if ((theme.id == "custom_image" || !effectiveUri.isNullOrEmpty()) && !effectiveUri.isNullOrEmpty()) {
            val fileModel = remember(effectiveUri) {
                if (effectiveUri.startsWith("file://")) {
                    val path = Uri.parse(effectiveUri).path
                    if (path != null) java.io.File(path) else effectiveUri
                } else if (effectiveUri.startsWith("/")) {
                    java.io.File(effectiveUri)
                } else {
                    effectiveUri
                }
            }
            AsyncImage(
                model = fileModel,
                contentDescription = "Custom theme background",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.40f),
                                Color.Black.copy(alpha = 0.65f),
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )
        } else {
            AestheticThemeBackground(
                themeId = theme.id,
                isPlaying = isPlaying,
                modifier = Modifier.fillMaxSize()
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(top = 16.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Header Row (Back, Title & Artist, Share)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowBack,
                        tint = Color.White,
                        contentDescription = "Back",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = song.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = song.artist ?: "<unknown>",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                IconButton(onClick = {
                    val sendIntent = android.content.Intent().apply {
                        action = android.content.Intent.ACTION_SEND
                        putExtra(android.content.Intent.EXTRA_TEXT, "Listening to: ${song.title} by ${song.artist ?: "Unknown"}")
                        type = "text/plain"
                    }
                    val shareIntent = android.content.Intent.createChooser(sendIntent, null)
                    context.startActivity(shareIntent)
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Share,
                        tint = Color.White,
                        contentDescription = "Share",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // 2. Central Rotating Disc & Circular Visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier.size(320.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularAudioVisualizer(
                        isPlaying = isPlaying,
                        modifier = Modifier.fillMaxSize()
                    )
                    
                    RotatingVinylDisc(
                        song = song,
                        isPlaying = isPlaying,
                        modifier = Modifier.size(242.dp)
                    )
                }
            }

            // 3. Action Buttons Row (Favorite, Equalizer, Timer, Theme, More)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val isFav = favoriteSongIds.contains(song.id)
                IconButton(onClick = {
                    musicViewModel.toggleFavorite(song.id)
                }) {
                    Icon(
                        imageVector = if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        tint = if (isFav) Color(0xFFFFD700) else Color.White,
                        contentDescription = "Favorite",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                IconButton(onClick = {
                    showEqualizerSettings = true
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        tint = Color.White,
                        contentDescription = "Equalizer",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                IconButton(onClick = { showSleepTimerDialog = true }) {
                    Icon(
                        imageVector = Icons.Rounded.Timer,
                        tint = Color.White,
                        contentDescription = "Sleep Timer",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                IconButton(onClick = {
                    initialAudioSettingsTab = "Premium Themes"
                    showAudioSettings = true
                }) {
                    Icon(
                        imageVector = TShirtIcon,
                        tint = Color.White,
                        contentDescription = "Themes",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                Box {
                    IconButton(onClick = { showMoreMenu = true }) {
                        Icon(
                            imageVector = Icons.Rounded.MoreVert,
                            tint = Color.White,
                            contentDescription = "More Options",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    DropdownMenu(
                        expanded = showMoreMenu,
                        onDismissRequest = { showMoreMenu = false },
                        modifier = Modifier.background(Color(0xFF1E1E1E))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Song Information", color = Color.White) },
                            onClick = {
                                showMoreMenu = false
                                showSongInfoDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Shuffle: " + if (shuffleEnabled) "ON" else "OFF", color = Color.White) },
                            onClick = {
                                showMoreMenu = false
                                musicViewModel.setShuffleMode(!shuffleEnabled)
                                Toast.makeText(context, if (!shuffleEnabled) "Shuffle Enabled" else "Shuffle Disabled", Toast.LENGTH_SHORT).show()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Speed: ${playbackSpeed}x", color = Color.White) },
                            onClick = {
                                showMoreMenu = false
                                initialAudioSettingsTab = "Audio Tuning"
                                showAudioSettings = true
                            }
                        )
                    }
                }
            }

            // 4. Timeline Seek Slider
            val effectiveDuration = if (duration > 0) duration else if (song.duration > 0) song.duration else 0L
            val progress = if (effectiveDuration > 0) (currentPosition.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f) else 0f
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatMusicMillis(currentPosition),
                    color = Color.Gray,
                    fontSize = 12.sp
                )
                
                Slider(
                    value = progress,
                    onValueChange = {
                        val targetMs = (it * effectiveDuration).toLong()
                        musicViewModel.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                )
                
                Text(
                    text = formatMusicMillis(effectiveDuration),
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }

            // 5. Bottom Playback Controls (Repeat, Skip Previous, Play/Pause Circle, Skip Next, Queue)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val repeatIcon = when (repeatMode) {
                    1 -> Icons.Rounded.RepeatOne
                    else -> Icons.Rounded.Repeat
                }
                val repeatTint = if (repeatMode != 0) theme.accentColor else Color.White
                
                IconButton(onClick = {
                    val nextMode = (repeatMode + 1) % 3
                    musicViewModel.setRepeatMode(nextMode)
                    val modeLabel = when (nextMode) {
                        0 -> "Repeat Off"
                        1 -> "Repeat One"
                        else -> "Repeat All"
                    }
                    Toast.makeText(context, modeLabel, Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        imageVector = repeatIcon,
                        tint = repeatTint,
                        contentDescription = "Repeat Mode",
                        modifier = Modifier.size(28.dp)
                    )
                }
                
                IconButton(onClick = { musicViewModel.previous() }) {
                    Icon(
                        imageVector = Icons.Rounded.SkipPrevious,
                        tint = Color.White,
                        contentDescription = "Previous",
                        modifier = Modifier.size(36.dp)
                    )
                }
                
                IconButton(
                    onClick = {
                        musicViewModel.togglePlayPause()
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .background(Color.White, CircleShape)
                        .testTag("expanded_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        tint = Color.Black,
                        contentDescription = "Play/Pause",
                        modifier = Modifier.size(38.dp)
                    )
                }
                
                IconButton(onClick = { musicViewModel.next() }) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        tint = Color.White,
                        contentDescription = "Next",
                        modifier = Modifier.size(36.dp)
                    )
                }
                
                IconButton(onClick = { showQueueBottomSheet = true }) {
                    Icon(
                        imageVector = Icons.Rounded.PlaylistPlay,
                        tint = Color.White,
                        contentDescription = "Queue",
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            // 6. Bottom Lyrics Preview Panel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable { showLyricsOverlay = true }
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lyrics preview",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowUp,
                        tint = Color.White,
                        contentDescription = "Expand Lyrics",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Full-screen audio settings sheet
        if (showAudioSettings) {
            AudioSettingsSheet(
                musicViewModel = musicViewModel,
                mediaViewModel = mediaViewModel,
                initialTab = initialAudioSettingsTab,
                onDismiss = { showAudioSettings = false }
            )
        }

        // Equalizer settings sheet
        if (showEqualizerSettings) {
            EqualizerSettingsSheet(
                musicViewModel = musicViewModel,
                onDismiss = { showEqualizerSettings = false },
                onExploreMore = {
                    showEqualizerSettings = false
                    initialAudioSettingsTab = "Audio Tuning"
                    showAudioSettings = true
                }
            )
        }

        // Sleep Timer Selection Dialog
        if (showSleepTimerDialog) {
            val sleepTimerMode by musicViewModel.sleepTimerMode.collectAsState()
            val sleepTimerRemaining by musicViewModel.sleepTimerRemaining.collectAsState()
            
            AlertDialog(
                onDismissRequest = { showSleepTimerDialog = false },
                title = { Text("Sleep Timer", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF1E1E24),
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        if (sleepTimerMode != null) {
                            Text(
                                text = "Active: $sleepTimerMode" + if (sleepTimerRemaining != null) " (${formatMusicMillis(sleepTimerRemaining!!)} remaining)" else "",
                                color = theme.accentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        
                        val timerOptions = listOf(
                            "Off" to null,
                            "5 Minutes" to 5,
                            "10 Minutes" to 10,
                            "15 Minutes" to 15,
                            "30 Minutes" to 30,
                            "45 Minutes" to 45,
                            "60 Minutes" to 60,
                            "End of Song" to -1
                        )
                        
                        timerOptions.forEach { (label, minutes) ->
                            TextButton(
                                onClick = {
                                    if (minutes == null) {
                                        musicViewModel.setSleepTimer(null)
                                        Toast.makeText(context, "Sleep Timer turned off", Toast.LENGTH_SHORT).show()
                                    } else if (minutes == -1) {
                                        musicViewModel.setSleepTimerEndOfSong()
                                        Toast.makeText(context, "Sleep Timer set to End of Song", Toast.LENGTH_SHORT).show()
                                    } else {
                                        musicViewModel.setSleepTimer(minutes)
                                        Toast.makeText(context, "Sleep Timer set for $minutes minutes", Toast.LENGTH_SHORT).show()
                                    }
                                    showSleepTimerDialog = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(vertical = 12.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (label == "Off" && sleepTimerMode == null) theme.accentColor else Color.White,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSleepTimerDialog = false }) {
                        Text("Cancel", color = theme.accentColor)
                    }
                }
            )
        }

        // Song Info Dialog
        if (showSongInfoDialog) {
            AlertDialog(
                onDismissRequest = { showSongInfoDialog = false },
                title = { Text("Song Information", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF1A1A1E),
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoRow("Title", song.title)
                        InfoRow("Artist", song.artist ?: "Unknown")
                        InfoRow("Album", song.album ?: "Unknown")
                        InfoRow("Duration", formatMusicMillis(song.duration))
                        InfoRow("File Size", String.format("%.2f MB", song.size / (1024f * 1024f)))
                        InfoRow("File Path", song.path)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showSongInfoDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.primaryColor)
                    ) {
                        Text("Close", color = Color.White)
                    }
                }
            )
        }

        // Full Screen Lyrics Overlay
        AnimatedVisibility(
            visible = showLyricsOverlay,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable(enabled = true, onClick = {})
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Lyrics",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp
                        )
                        IconButton(
                            onClick = { showLyricsOverlay = false },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.1f), CircleShape)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(song.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                        Text(song.artist ?: "Unknown Artist", color = theme.accentColor, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            LyricLine("Deep beats echoing in the silence", active = false)
                            LyricLine("Streaming high-fidelity pure frequency", active = false)
                            LyricLine("We are floating in the acoustic sanctuary", active = true)
                            LyricLine("Offline tranquility wash away your worries", active = false)
                            LyricLine("Studio grade dynamic resonance", active = false)
                            LyricLine("Spinning clean on a physical drive", active = false)
                            LyricLine("Chasing notes until the sunrise breaks...", active = false)
                        }
                    }
                }
            }
        }

        // Queue list Bottom Drawer
        AnimatedVisibility(
            visible = showQueueBottomSheet,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable(enabled = true, onClick = {})
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Current Queue",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp
                            )
                            val qSize by musicViewModel.queue.collectAsState()
                            Text(
                                text = "${qSize.size} tracks loaded",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { musicViewModel.clearQueue() }) {
                                Text("Clear All", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            IconButton(
                                onClick = { showQueueBottomSheet = false },
                                modifier = Modifier.background(Color.White.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(modifier = Modifier.weight(1f)) {
                        QueueTab(musicViewModel = musicViewModel, theme = theme)
                    }
                }
            }
        }
    }
}

@Composable
fun RotatingVinylDisc(
    song: ScannedSong,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "VinylSpin")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "VinylRotation"
    )

    Box(
        modifier = modifier
            .shadow(24.dp, CircleShape, ambientColor = Color.White, spotColor = Color.White)
            .border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape)
            .rotate(if (isPlaying) rotationAngle else 0f)
            .background(
                Brush.sweepGradient(
                    colors = listOf(Color.Black, Color.DarkGray, Color.Black, Color.DarkGray, Color.Black)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 2.3f, style = Stroke(1.5f))
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 3.0f, style = Stroke(1.5f))
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 4.0f, style = Stroke(1.5f))
        }

        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(Color.DarkGray)
        ) {
            AsyncImage(
                model = song.artworkUri,
                contentDescription = "Album Artwork",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun CircularAudioVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "VisualizerSpin")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "VisualizerPhase"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = size.width * 0.42f
        val barCount = 48

        for (i in 0 until barCount) {
            val angle = (i * 360f / barCount) * (Math.PI / 180f)
            val factor = if (isPlaying) (0.3f + 0.7f * kotlin.math.abs(sin(phase + i * 0.5f))) else 0.15f
            val barLen = 18.dp.toPx() * factor

            val startX = cx + baseRadius * cos(angle).toFloat()
            val startY = cy + baseRadius * sin(angle).toFloat()
            val endX = cx + (baseRadius + barLen) * cos(angle).toFloat()
            val endY = cy + (baseRadius + barLen) * sin(angle).toFloat()

            drawLine(
                color = Color.White.copy(alpha = 0.6f + factor * 0.4f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Column {
        Text(text = label, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun QueueTab(musicViewModel: MusicViewModel, theme: MusicTheme) {
    val queueList by musicViewModel.queue.collectAsState()
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Playing Queue (${queueList.size} tracks)",
                color = Color.Gray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            TextButton(
                onClick = { musicViewModel.clearQueue() },
                colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clear Queue", fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (queueList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("Queue is empty", color = Color.DarkGray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(queueList, key = { index, song -> "queue_${song.id}_$index" }) { index, song ->
                    val isActive = song.id == activeTrack?.id
                    val cardBg = if (isActive) theme.primaryColor.copy(alpha = 0.2f) else theme.cardBackground
                    val cardBorder = if (isActive) theme.accentColor else Color.Transparent

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(cardBg)
                            .border(1.dp, cardBorder, RoundedCornerShape(12.dp))
                            .clickable {
                                musicViewModel.playSong(song, queueList)
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = song.artworkUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = if (isActive) theme.accentColor else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist ?: "Unknown Artist",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(onClick = { musicViewModel.removeFromQueue(song.id) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LyricLine(text: String, active: Boolean) {
    Text(
        text = text,
        color = if (active) ElectricBlue else Color.White.copy(alpha = 0.4f),
        fontWeight = if (active) FontWeight.Black else FontWeight.Normal,
        fontSize = if (active) 18.sp else 15.sp,
        textAlign = TextAlign.Center,
        style = androidx.compose.ui.text.TextStyle(
            shadow = if (active) Shadow(ElectricBlue, blurRadius = 8f) else null
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

private fun formatMusicMillis(ms: Long): String {
    if (ms <= 0) return "00:00"
    val totalSecs = ms / 1000
    val minutes = totalSecs / 60
    val seconds = totalSecs % 60
    return String.format("%02d:%02d", minutes, seconds)
}

@Composable
fun AudioSettingsSheet(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    initialTab: String = "Audio Tuning",
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val currentTheme by musicViewModel.currentTheme.collectAsState()
    val customThemeImageUri by musicViewModel.customThemeImageUri.collectAsState()
    var settingsTab by remember { mutableStateOf(initialTab) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val file = java.io.File(context.filesDir, "custom_theme_bg.jpg")
                    file.outputStream().use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                    val localUri = Uri.fromFile(file).toString()
                    com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                        musicViewModel.setCustomThemeImage(localUri)
                        mediaViewModel?.setCustomBackgroundUri(localUri)
                        mediaViewModel?.setSelectedThemeId("custom_image")
                        Toast.makeText(context, "Custom theme applied successfully!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable(enabled = true, onClick = {})
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Audio Studio & Themes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val tabs = listOf("Audio Tuning", "Premium Themes")
                tabs.forEach { tab ->
                    val isSelected = settingsTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) ElectricBlue else Color.White.copy(alpha = 0.08f))
                            .clickable { settingsTab = tab }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            color = if (isSelected) Color.Black else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (settingsTab == "Premium Themes") {
                // Theme Selection Tab
                Column(modifier = Modifier.fillMaxSize()) {
                    // Custom Photo Theme Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                            .clickable { launcher.launch("image/*") }
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Set Custom Gallery Background", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Choose your favorite photo from phone storage", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Soundscape Themes",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )

                    val allThemes = MusicThemeRegistry.BuiltInThemes
                    val themePairs = allThemes.chunked(2)

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(themePairs.size) { index ->
                            val pair = themePairs[index]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                pair.forEach { theme ->
                                    val isCurrent = currentTheme.id == theme.id
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(Color.White.copy(alpha = 0.02f))
                                            .border(
                                                width = if (isCurrent) 2.dp else 1.dp,
                                                color = if (isCurrent) theme.accentColor else Color.White.copy(alpha = 0.08f),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                                    musicViewModel.selectTheme(theme.id)
                                                }
                                            }
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            // Mini visual preview card
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(80.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .border(1.dp, theme.glassBorderColor, RoundedCornerShape(8.dp))
                                            ) {
                                                AestheticThemeBackground(
                                                    themeId = theme.id,
                                                    isPlaying = false,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = theme.name,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                if (isCurrent) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(ElectricBlue)
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("Active", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (pair.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            } else {
                // Audio Tuning Panel
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LuxurySettingsCard(title = "10-Band Equalizer", icon = Icons.Rounded.Equalizer, theme = currentTheme) {
                            Text("10-Band Precision Equalizer Active", color = Color.White, fontSize = 13.sp)
                        }

                        LuxurySettingsCard(title = "Studio Enhancements", icon = Icons.Rounded.SettingsVoice, theme = currentTheme) {
                            Text("Bass Boost & Virtualizer 3D Sound", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LuxurySettingsCard(
    title: String,
    icon: ImageVector,
    theme: MusicTheme,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, theme.glassBorderColor, RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = theme.accentColor, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun VerticalEqualizerSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = -15f..15f,
    enabled: Boolean = true
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxHeight()
            .width(42.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { offset ->
                    val pct = (1f - (offset.y / size.height.toFloat())).coerceIn(0f, 1f)
                    val newVal = range.start + pct * (range.endInclusive - range.start)
                    onValueChange(newVal)
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { offset ->
                        val pct = (1f - (offset.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val newVal = range.start + pct * (range.endInclusive - range.start)
                        onValueChange(newVal)
                    },
                    onDrag = { change, _ ->
                        val pct = (1f - (change.position.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val newVal = range.start + pct * (range.endInclusive - range.start)
                        onValueChange(newVal)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val percent = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)

        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val trackWidth = 3.dp.toPx()
            val thumbRadius = 7.dp.toPx()
            val thumbYPx = size.height * (1f - percent)
            
            drawLine(
                color = Color.White.copy(alpha = 0.15f),
                start = Offset(cx, 0f),
                end = Offset(cx, thumbYPx),
                strokeWidth = trackWidth,
                cap = StrokeCap.Round
            )

            drawLine(
                color = if (enabled) Color(0xFF2ECC71) else Color.Gray.copy(alpha = 0.5f),
                start = Offset(cx, thumbYPx),
                end = Offset(cx, size.height),
                strokeWidth = trackWidth,
                cap = StrokeCap.Round
            )

            drawCircle(
                color = if (enabled) Color.White else Color.Gray,
                radius = thumbRadius,
                center = Offset(cx, thumbYPx)
            )
        }
    }
}

@Composable
fun MusicExpandedPlayer(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    onCollapse: () -> Unit
) {
    MusicPlayerView(
        musicViewModel = musicViewModel,
        mediaViewModel = mediaViewModel,
        onCollapse = onCollapse
    )
}

@Composable
fun MusicMiniPlayer(
    musicViewModel: MusicViewModel,
    onExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val song by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val theme by musicViewModel.currentTheme.collectAsState()
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()

    val activeSong = song ?: return
    val effectiveDuration = if (duration > 0) duration else if (activeSong.duration > 0) activeSong.duration else 1L
    val progress = (currentPosition.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1E1E24).copy(alpha = 0.95f))
            .border(1.dp, theme.glassBorderColor, RoundedCornerShape(16.dp))
            .clickable { onExpand() }
            .padding(8.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    AsyncImage(
                        model = activeSong.artworkUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeSong.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = activeSong.artist ?: "Unknown Artist",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = { musicViewModel.togglePlayPause() }) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        tint = Color.White,
                        contentDescription = "Play/Pause",
                        modifier = Modifier.size(28.dp)
                    )
                }

                IconButton(onClick = { musicViewModel.next() }) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        tint = Color.White,
                        contentDescription = "Next",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .background(theme.accentColor)
                )
            }
        }
    }
}

@Composable
fun EqualizerSettingsSheet(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit,
    onExploreMore: () -> Unit
) {
    val eqEnabled by musicViewModel.eqEnabled.collectAsState()
    val selectedPreset by musicViewModel.selectedPreset.collectAsState()
    val eqBands by musicViewModel.eqBands.collectAsState()

    val bassBoostStrength by musicViewModel.bassBoostStrength.collectAsState()
    val virtualizerStrength by musicViewModel.virtualizerStrength.collectAsState()
    val reverbPreset by musicViewModel.reverbPreset.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(enabled = true, onClick = onDismiss)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFF121212))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickable(enabled = true, onClick = {})
                .padding(vertical = 20.dp, horizontal = 24.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronLeft,
                        tint = Color.White,
                        contentDescription = "Back",
                        modifier = Modifier.size(32.dp)
                    )
                }
                
                Text(
                    text = "Equalizer",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = if (eqEnabled) "ON" else "OFF",
                    color = if (eqEnabled) Color(0xFF2ECC71) else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )

                Switch(
                    checked = eqEnabled,
                    onCheckedChange = { musicViewModel.setEqEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2ECC71),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.DarkGray
                    ),
                    modifier = Modifier.testTag("eq_switch")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Preset Pills Row
            val presets = listOf("Bass Boost", "EDM Heavy", "Rock", "Pop", "Jazz", "Classical", "Cinema", "3D Spatial", "Vocal", "Club", "Normal", "Custom")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                presets.forEach { preset ->
                    val isSelected = selectedPreset == preset
                    val badgeColor = when (preset) {
                        "Bass Boost", "EDM Heavy" -> Color(0xFFFF0055)
                        "3D Spatial", "Cinema" -> Color(0xFF00E5FF)
                        "Rock", "Club" -> Color(0xFF9C27B0)
                        "Pop", "Vocal" -> Color(0xFFFF9800)
                        else -> Color(0xFF10B981)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                if (isSelected) Brush.horizontalGradient(
                                    listOf(badgeColor, badgeColor.copy(alpha = 0.7f))
                                ) else Brush.horizontalGradient(
                                    listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.05f))
                                )
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) badgeColor else Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .clickable {
                                musicViewModel.selectPreset(preset)
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val icon = when (preset) {
                                "Bass Boost" -> Icons.Rounded.GraphicEq
                                "EDM Heavy" -> Icons.Rounded.ElectricBolt
                                "3D Spatial" -> Icons.Rounded.SurroundSound
                                "Cinema" -> Icons.Rounded.Movie
                                "Rock" -> Icons.Rounded.VolumeUp
                                "Vocal" -> Icons.Rounded.Mic
                                else -> Icons.Rounded.MusicNote
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else badgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = preset,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 5 Vertical Equalizer Sliders with dB Readouts
            val frequencies = listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 5) {
                    val band1 = i * 2
                    val band2 = i * 2 + 1
                    val bandGain = eqBands.getOrElse(band1) { 0 }
                    
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Text(
                            text = if (bandGain > 0) "+${bandGain}dB" else "${bandGain}dB",
                            color = if (bandGain != 0) Color(0xFF10B981) else Color.Gray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        VerticalEqualizerSlider(
                            value = bandGain.toFloat(),
                            onValueChange = { newVal ->
                                musicViewModel.setEqBand(band1, newVal.toInt())
                                musicViewModel.setEqBand(band2, newVal.toInt())
                                musicViewModel.selectPreset("Custom")
                            },
                            range = -15f..15f,
                            enabled = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = frequencies[i],
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // BassBooster Pro and 3D Spatial Audio Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // BassBoost Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1028)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFFF007A).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.GraphicEq,
                                    contentDescription = null,
                                    tint = Color(0xFFFF007A),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("Bass Boost", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text("${bassBoostStrength / 10}%", color = Color(0xFFFF007A), fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Slider(
                            value = bassBoostStrength.toFloat(),
                            onValueChange = {
                                musicViewModel.setBassBoostEnabled(true)
                                musicViewModel.setBassBoostStrength(it.toInt())
                            },
                            valueRange = 0f..1000f,
                            enabled = true,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF007A),
                                activeTrackColor = Color(0xFFFF007A),
                                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // 3D Virtualizer Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2A)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.SurroundSound,
                                    contentDescription = null,
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("3D Spatial", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text("${virtualizerStrength / 10}%", color = Color(0xFF00E5FF), fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Slider(
                            value = virtualizerStrength.toFloat(),
                            onValueChange = {
                                musicViewModel.setVirtualizerEnabled(true)
                                musicViewModel.setVirtualizerStrength(it.toInt())
                            },
                            valueRange = 0f..1000f,
                            enabled = true,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF),
                                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Bottom pill: "Explore more equalizer settings >"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                    .clickable { onExploreMore() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Explore more equalizer settings ",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        tint = Color.White.copy(alpha = 0.85f),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
