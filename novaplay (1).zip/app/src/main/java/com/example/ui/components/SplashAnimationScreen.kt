package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Stars
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashAnimationScreen(
    appLanguage: String,
    onFinished: () -> Unit
) {
    // 8 seconds loading duration as requested
    LaunchedEffect(Unit) {
        delay(8000)
        onFinished()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "SplashScreenInfinite")

    // Animated states for sequential aesthetic reveal
    var logoVisible by remember { mutableStateOf(false) }
    var textVisible by remember { mutableStateOf(false) }
    var taglineVisible by remember { mutableStateOf(false) }
    var progressVal by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        delay(100)
        logoVisible = true
        delay(300)
        textVisible = true
        delay(250)
        taglineVisible = true
    }

    // Dynamic step progress filling smoothly over 7.8 seconds
    LaunchedEffect(Unit) {
        val durationMs = 7800L
        val steps = 100
        val stepDelay = durationMs / steps
        for (i in 1..steps) {
            delay(stepDelay)
            progressVal = i.toFloat() / steps
        }
        progressVal = 1.0f
    }

    // Spring animations for icon entry
    val logoScale by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0.3f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "LogoScale"
    )

    val logoAlpha by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0f,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "LogoAlpha"
    )

    val textAlpha by animateFloatAsState(
        targetValue = if (textVisible) 1f else 0f,
        animationSpec = tween(900, easing = EaseOutCubic),
        label = "TextAlpha"
    )

    val taglineAlpha by animateFloatAsState(
        targetValue = if (taglineVisible) 1f else 0f,
        animationSpec = tween(1100, easing = EaseOutCubic),
        label = "TaglineAlpha"
    )

    // Pulsing outer halo scale
    val haloPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.30f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "HaloPulse"
    )

    // Glowing rotating tricolor circle ring
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    val badgePulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BadgePulse"
    )

    val comparisonSlogan = when {
        appLanguage.isEmpty() -> "Playit और MX Player से बेहतर, भारत का अपना Vidiopen"
        appLanguage == "en" -> "The Best Indian Alternative to Playit / MX Player"
        else -> "Playit और MX Player से बेहतर, भारत का अपना Vidiopen"
    }

    // Dynamic status messages
    val statusText = when {
        progressVal < 0.2f -> if (appLanguage == "hi") "1080P वीडियो इंजन शुरू हो रहा है..." else "Initializing 1080P Video Engine..."
        progressVal < 0.4f -> if (appLanguage == "hi") "हार्डवेयर डिकोडिंग सेट हो रही है..." else "Configuring Hardware Acceleration..."
        progressVal < 0.6f -> if (appLanguage == "hi") "ऑफ़लाइन मीडिया स्कैन किया जा रहा है..." else "Scanning Local Media Files..."
        progressVal < 0.8f -> if (appLanguage == "hi") "स्वाइप जेस्चर नियंत्रण तैयार हो रहे हैं..." else "Loading Smooth Gesture Controls..."
        progressVal < 0.95f -> if (appLanguage == "hi") "ऑडियो/वीडियो बफ़र ऑप्टिमाइज़ हो रहे हैं..." else "Optimizing Playback Buffers..."
        else -> if (appLanguage == "hi") "तैयार! वीडियो प्लेयर खुल रहा है..." else "Ready! Launching Video Player..."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06060A)), // Deep midnight black background
        contentAlignment = Alignment.Center
    ) {
        // Subtle ambient radial background glow (Saffron & Green blend)
        Box(
            modifier = Modifier
                .size(520.dp)
                .align(Alignment.Center)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFF9933).copy(alpha = 0.12f),
                            Color(0xFF138808).copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Background animated ambient particle sparkles
        Canvas(modifier = Modifier.fillMaxSize()) {
            val starPositions = listOf(
                Offset(size.width * 0.15f, size.height * 0.12f),
                Offset(size.width * 0.85f, size.height * 0.08f),
                Offset(size.width * 0.72f, size.height * 0.28f),
                Offset(size.width * 0.25f, size.height * 0.35f),
                Offset(size.width * 0.88f, size.height * 0.68f),
                Offset(size.width * 0.12f, size.height * 0.75f),
                Offset(size.width * 0.35f, size.height * 0.85f),
                Offset(size.width * 0.65f, size.height * 0.92f)
            )
            starPositions.forEachIndexed { i, offset ->
                val alpha = if (i % 2 == 0) 0.5f else 0.3f
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = if (i % 3 == 0) 3.5f else 2f,
                    center = offset
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
        ) {
            // Animated App Icon Box with Tricolor Halo Glow
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(170.dp)
                    .scale(logoScale)
                    .alpha(logoAlpha)
            ) {
                // Pulse halo bloom
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(haloPulse)
                        .blur(16.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFFF9933).copy(alpha = 0.35f),
                                    Color(0xFF138808).copy(alpha = 0.25f),
                                    Color.Transparent
                                )
                            ),
                            CircleShape
                        )
                )

                // Rotating Tricolor Gradient Border Ring around Logo
                Canvas(
                    modifier = Modifier
                        .size(148.dp)
                        .graphicsLayer(rotationZ = rotationAngle)
                ) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFFFF9933), // Indian Saffron
                                Color(0xFFFFFFFF), // White
                                Color(0xFF138808), // Indian Green
                                Color(0xFF000080), // Ashoka Blue
                                Color(0xFFFF9933)  // Back to Saffron
                            )
                        ),
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Inner dark backing container for App Logo
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .background(Color(0xFF0F0F16), CircleShape)
                        .border(1.5.dp, Color.White.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Main App Logo Icon
                    AppLogo(
                        modifier = Modifier.size(80.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Main Brand Name Text
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "VIDIOPEN",
                    color = Color.White,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .alpha(textAlpha)
                        .graphicsLayer(scaleX = textAlpha, scaleY = textAlpha)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Short tagline under brand
                Text(
                    text = if (appLanguage == "hi") "अल्टीमेट 1080P मीडिया प्लेयर" else "ULTIMATE 1080P MEDIA PLAYER",
                    color = Color.LightGray.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.alpha(taglineAlpha)
                )
            }

            Spacer(modifier = Modifier.height(48.dp))

            // 5-Second Tricolor Progress Loading Bar
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(230.dp)
                    .alpha(taglineAlpha)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.5.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progressVal)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFFF9933), // Saffron
                                        Color(0xFFFFFFFF), // White
                                        Color(0xFF138808)  // Green
                                    )
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = statusText,
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Extremely Attractive "Better than Playit & MX Player" Bottom Section with Indian Flag & Icons
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 28.dp, start = 16.dp, end = 16.dp)
                .alpha(taglineAlpha),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Glassmorphic Tricolor Badge Card with Pulsing Scale
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101018).copy(alpha = 0.94f)),
                border = BorderStroke(
                    1.5.dp,
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFFFF9933),
                            Color(0xFFFF007A),
                            Color(0xFF00E5FF),
                            Color(0xFF138808)
                        )
                    )
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
                modifier = Modifier.graphicsLayer(scaleX = badgePulseScale, scaleY = badgePulseScale)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .background(
                                    brush = Brush.radialGradient(
                                        listOf(Color(0xFFFF5722), Color(0xFFFF007A))
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Custom Drawn Authentic Indian Flag Badge
                        IndianFlagBadge()

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "🇮🇳",
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = comparisonSlogan,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        letterSpacing = 0.2.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Tricolor horizontal micro-line
                    Row(
                        modifier = Modifier
                            .width(200.dp)
                            .height(2.5.dp)
                            .clip(CircleShape)
                    ) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFFF9933)))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.White))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF138808)))
                    }
                }
            }
        }
    }
}

@Composable
fun IndianFlagBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .width(32.dp)
            .height(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Saffron
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFFFF9933))
            )
            // White with Ashoka Chakra
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(6.dp)) {
                    val radius = size.minDimension / 2f
                    drawCircle(
                        color = Color(0xFF000080),
                        radius = radius,
                        style = Stroke(width = 0.8f)
                    )
                    for (i in 0 until 24) {
                        val angle = Math.toRadians((i * 15).toDouble())
                        val x = center.x + radius * Math.cos(angle).toFloat()
                        val y = center.y + radius * Math.sin(angle).toFloat()
                        drawLine(
                            color = Color(0xFF000080),
                            start = center,
                            end = Offset(x, y),
                            strokeWidth = 0.5f
                        )
                    }
                }
            }
            // Green
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF138808))
            )
        }
    }
}
