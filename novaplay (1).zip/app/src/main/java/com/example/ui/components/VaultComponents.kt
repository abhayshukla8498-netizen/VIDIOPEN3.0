package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RoyalPurple
import kotlin.math.sqrt
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

// --- Premium Luxury Glassmorphic Keypad for PIN ---
@Composable
fun GlassPinKeypad(
    onDigitClick: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    onClearClick: () -> Unit,
    showBiometric: Boolean,
    onBiometricClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("clear", "0", "backspace")
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxWidth()
    ) {
        keys.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1.5f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (key == "clear" || key == "backspace") Color.White.copy(alpha = 0.03f)
                                else Color.White.copy(alpha = 0.06f)
                            )
                            .border(
                                1.dp,
                                Color.White.copy(alpha = if (key == "clear" || key == "backspace") 0.05f else 0.1f),
                                RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                when (key) {
                                    "backspace" -> onBackspaceClick()
                                    "clear" -> onClearClick()
                                    else -> onDigitClick(key)
                                }
                            }
                            .testTag("keypad_btn_$key"),
                        contentAlignment = Alignment.Center
                    ) {
                        when (key) {
                            "backspace" -> {
                                Icon(
                                    imageVector = Icons.Rounded.Backspace,
                                    contentDescription = "Backspace",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            "clear" -> {
                                if (showBiometric) {
                                    Icon(
                                        imageVector = Icons.Rounded.Fingerprint,
                                        contentDescription = "Biometric Unlock",
                                        tint = ElectricBlue,
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clickable { onBiometricClick() }
                                    )
                                } else {
                                    Text(
                                        text = "C",
                                        color = Color.Gray,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                            }
                            else -> {
                                Text(
                                    text = key,
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Glowing Interactive Pattern Lock Grid (3x3) ---
@Composable
fun PatternLockGrid(
    onPatternComplete: (String) -> Unit,
    modifier: Modifier = Modifier,
    normalColor: Color = Color.White.copy(alpha = 0.2f),
    selectedColor: Color = RoyalPurple,
    lineColor: Color = ElectricBlue
) {
    var selectedDots by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentTouchPoint by remember { mutableStateOf<Offset?>(null) }

    val dotRadius = with(LocalDensity.current) { 10.dp.toPx() }
    val selectionThreshold = with(LocalDensity.current) { 32.dp.toPx() }

    // Store dot center coordinates once drawn
    val dotCenters = remember { mutableStateMapOf<Int, Offset>() }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        selectedDots = emptyList()
                        currentTouchPoint = offset
                        // Detect initial dot
                        dotCenters.forEach { (index, center) ->
                            if (distance(offset, center) < selectionThreshold) {
                                selectedDots = selectedDots + index
                            }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newPoint = change.position
                        currentTouchPoint = newPoint

                        dotCenters.forEach { (index, center) ->
                            if (distance(newPoint, center) < selectionThreshold) {
                                if (index !in selectedDots) {
                                    selectedDots = selectedDots + index
                                }
                            }
                        }
                    },
                    onDragEnd = {
                        if (selectedDots.isNotEmpty()) {
                            onPatternComplete(selectedDots.joinToString(""))
                        }
                        selectedDots = emptyList()
                        currentTouchPoint = null
                    },
                    onDragCancel = {
                        selectedDots = emptyList()
                        currentTouchPoint = null
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellWidth = size.width / 3f
            val cellHeight = size.height / 3f

            // 1. Calculate centers
            for (row in 0 until 3) {
                for (col in 0 until 3) {
                    val index = row * 3 + col
                    val x = col * cellWidth + cellWidth / 2f
                    val y = row * cellHeight + cellHeight / 2f
                    dotCenters[index] = Offset(x, y)
                }
            }

            // 2. Draw connections
            if (selectedDots.isNotEmpty()) {
                for (i in 0 until selectedDots.size - 1) {
                    val start = dotCenters[selectedDots[i]] ?: Offset.Zero
                    val end = dotCenters[selectedDots[i + 1]] ?: Offset.Zero
                    drawLine(
                        color = lineColor,
                        start = start,
                        end = end,
                        strokeWidth = 8f,
                        cap = StrokeCap.Round
                    )
                }

                // Draw line to current finger position
                currentTouchPoint?.let { finger ->
                    val lastDotCenter = dotCenters[selectedDots.last()] ?: Offset.Zero
                    drawLine(
                        color = lineColor.copy(alpha = 0.5f),
                        start = lastDotCenter,
                        end = finger,
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Draw dots
            for (i in 0 until 9) {
                val center = dotCenters[i] ?: Offset.Zero
                val isSelected = i in selectedDots
                drawCircle(
                    color = if (isSelected) selectedColor else normalColor,
                    radius = if (isSelected) dotRadius * 1.3f else dotRadius,
                    center = center
                )
                if (isSelected) {
                    // Draw outer pulse ring
                    drawCircle(
                        color = lineColor.copy(alpha = 0.3f),
                        radius = dotRadius * 2.2f,
                        center = center,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                    )
                }
            }
        }
    }
}

private fun distance(p1: Offset, p2: Offset): Float {
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y))
}

// --- Luxury Category Card ---
@Composable
fun VaultCategoryCard(
    title: String,
    count: Int,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622).copy(alpha = 0.6f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
            .testTag("vault_cat_${title.lowercase()}")
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f))
                    .padding(10.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = "$count Items",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

// --- Secure Elegant Empty State ---
@Composable
fun ElegantVaultEmptyState(
    icon: ImageVector,
    title: String,
    description: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.03f))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape)
                    .padding(24.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.size(48.dp)
                )
            }
            Text(
                text = title,
                color = Color.White.copy(alpha = 0.8f),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = description,
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

// --- Luxury Password Lock View ---
@Composable
fun PasswordLockInputView(
    onPasswordSubmit: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            placeholder = { Text("Enter Vault Password", color = Color.Gray) },
            visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
            trailingIcon = {
                val icon = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(imageVector = icon, contentDescription = "Toggle password visibility", tint = Color.Gray)
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = RoyalPurple,
                unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                focusedContainerColor = Color(0xFF161622),
                unfocusedContainerColor = Color(0xFF161622)
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("vault_password_input")
        )

        Button(
            onClick = {
                if (passwordInput.isNotEmpty()) {
                    onPasswordSubmit(passwordInput)
                    passwordInput = ""
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("vault_password_btn")
        ) {
            Text("Unlock Secure Vault", fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

// --- Secure Premium Document Reader / Viewer ---
@Composable
fun SecureDocumentReader(
    file: java.io.File,
    title: String,
    onBack: () -> Unit,
    onExport: () -> Unit
) {
    var textContent by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(file) {
        isLoading = true
        textContent = try {
            if (file.extension.lowercase() in listOf("txt", "json", "xml", "csv", "md", "kt", "java")) {
                file.readText(Charsets.UTF_8)
            } else {
                null // Non-text file
            }
        } catch (e: Exception) {
            "Failed to load secure document preview: ${e.localizedMessage}"
        } finally {
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(
                text = title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            IconButton(onClick = onExport) {
                Icon(Icons.Rounded.IosShare, contentDescription = "Export Secure File", tint = ElectricBlue)
            }
        }

        Divider(color = Color.White.copy(alpha = 0.08f))

        if (isLoading) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = RoyalPurple)
            }
        } else {
            if (textContent != null) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp)
                        .background(Color(0xFF161622), RoundedCornerShape(16.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    androidx.compose.foundation.rememberScrollState().let { scrollState ->
                        Text(
                            text = textContent!!,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                        )
                    }
                }
            } else {
                // Binary Document View (PDF, DOCX, ZIP, etc.)
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.03f))
                                .padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Description,
                                contentDescription = "Secure Document",
                                tint = ElectricBlue,
                                modifier = Modifier.size(64.dp)
                            )
                        }
                        Text(
                            text = "Secure Preview Unavailable",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "This file type (${file.extension.uppercase()}) is securely encrypted. Export the file to view it in external document editors.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onExport,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.IosShare, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Decrypt & Export", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
