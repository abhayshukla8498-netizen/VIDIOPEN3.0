package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val ElectricBlue = Color(0xFF00D9FF)
val RoyalPurple = Color(0xFF7C4DFF)
val GlassWhite = Color(0x1FFFFFFF)
val GlassWhiteBorder = Color(0x33FFFFFF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9E9E9E)

val DarkGray = Color(0xFF121212)
val CardBackground = Color(0xFF1E1E1E)
val PrimaryGlow = Color(0x3D00D9FF)
