package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class MusicTheme(
    val id: String,
    val name: String,
    val isDark: Boolean = true,
    val backgroundColor: Color = Color.Black,
    val backgroundBrush: Brush? = null,
    val accentColor: Color = Color(0xFF00D9FF),     // Used for sliders, progress indicators, active icons
    val primaryColor: Color = Color(0xFF7C4DFF),    // Used for main buttons, primary highlights
    val cardBackground: Color = Color(0x0FFFFFFF),  // Card background color
    val textColor: Color = Color.White,
    val subtitleColor: Color = Color(0xFF9E9E9E),
    val glassBorderColor: Color = Color(0x33FFFFFF),
    val bgImageUri: String? = null                  // Used if a custom image/photo background is set
) {
    // Helper to get actual background modifier brush
    fun getBgBrush(): Brush {
        return backgroundBrush ?: Brush.verticalGradient(listOf(backgroundColor, backgroundColor))
    }
}

object MusicThemeRegistry {
    val BuiltInThemes = listOf(
        MusicTheme(
            id = "moonlight_night",
            name = "Moonlight Night",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF080B12), Color(0xFF101626))
            ),
            accentColor = Color(0xFFFF3366),
            primaryColor = Color(0xFFE0E0E0),
            cardBackground = Color(0x22101626),
            glassBorderColor = Color(0x44FFFFFF)
        ),
        MusicTheme(
            id = "foggy_city",
            name = "Foggy City",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0C0F17), Color(0xFF1E2838), Color(0xFF10141D))
            ),
            accentColor = Color(0xFF111111),
            primaryColor = Color(0xFFE8C59C),
            cardBackground = Color(0x22000000),
            glassBorderColor = Color(0x33000000)
        ),
        MusicTheme(
            id = "glowing_notes",
            name = "Glowing Notes",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF00363A), Color(0xFF0A192F), Color(0xFF3E2723))
            ),
            accentColor = Color(0xFFFFB74D),
            primaryColor = Color(0xFF00E5FF),
            cardBackground = Color(0x2200E5FF),
            glassBorderColor = Color(0x44FFB74D)
        ),
        MusicTheme(
            id = "headphones_wave",
            name = "Headphones Wave",
            backgroundColor = Color(0xFF000000),
            accentColor = Color(0xFFFFFFFF),
            primaryColor = Color(0xFFE0E0E0),
            cardBackground = Color(0xFF121212),
            glassBorderColor = Color(0x33FFFFFF)
        ),
        MusicTheme(
            id = "dark_collage",
            name = "Music Collage",
            backgroundColor = Color(0xFF121212),
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF181818), Color(0xFF0A0A0A))
            ),
            accentColor = Color(0xFFFFFFFF),
            primaryColor = Color(0xFF888888),
            cardBackground = Color(0xFF242424),
            glassBorderColor = Color(0x33FFFFFF)
        )
    )

    fun getThemeById(id: String, customUri: String? = null): MusicTheme {
        if (id == "custom_image" && customUri != null) {
            return MusicTheme(
                id = "custom_image",
                name = "Favorite Image",
                backgroundColor = Color.Black.copy(alpha = 0.5f), // Translucent overlay to see the image
                accentColor = Color(0xFF00D9FF),
                primaryColor = Color(0xFF7C4DFF),
                cardBackground = Color(0x2A000000),
                glassBorderColor = Color(0x22FFFFFF),
                bgImageUri = customUri
            )
        }
        return BuiltInThemes.find { it.id == id } ?: BuiltInThemes.first()
    }
}
