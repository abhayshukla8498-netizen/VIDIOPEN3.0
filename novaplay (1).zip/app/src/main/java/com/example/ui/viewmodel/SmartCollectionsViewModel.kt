package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScannedVideo
import com.example.data.model.SmartCollectionItem
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import java.io.File

class SmartCollectionsViewModel(
    application: Application,
    private val mediaRepository: MediaRepository
) : AndroidViewModel(application) {

    private val _scannedVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())
    val scannedVideos: StateFlow<List<ScannedVideo>> = _scannedVideos.asStateFlow()

    private val _recentlyOpenedFolder = MutableStateFlow<String?>(null)
    val recentlyOpenedFolder: StateFlow<String?> = _recentlyOpenedFolder.asStateFlow()

    init {
        viewModelScope.launch {
            _recentlyOpenedFolder.value = mediaRepository.getConfig("recently_opened_folder_path")
        }
    }

    fun setRecentlyOpenedFolder(path: String) {
        _recentlyOpenedFolder.value = path
        viewModelScope.launch {
            mediaRepository.setConfig("recently_opened_folder_path", path)
        }
    }

    fun updateScannedVideos(videos: List<ScannedVideo>) {
        _scannedVideos.value = videos
    }

    // Reactive pipeline combining all sources to compute smart collections asynchronously
    val smartCollections: StateFlow<List<SmartCollectionItem>> = combine(
        _scannedVideos,
        mediaRepository.favorites,
        mediaRepository.watchHistory,
        mediaRepository.continueWatching
    ) { scanned, favs, history, cont ->
        if (scanned.isEmpty()) return@combine emptyList()

        val favIds = favs.filter { it.isFavorite }.map { it.id }.toSet()
        val historyMap = history.associateBy { it.id }
        val contMap = cont.associateBy { it.id }

        // 1. Continue Watching
        val continueWatchingVideos = scanned.filter { video ->
            val mediaEntity = contMap["scanned_${video.id}"]
            mediaEntity != null && mediaEntity.lastPlayedPosition > 0 && mediaEntity.lastPlayedPosition < video.duration - 2000L
        }.sortedByDescending { video ->
            historyMap["scanned_${video.id}"]?.watchedTimestamp ?: 0L
        }

        // 2. Recently Added
        val recentlyAddedVideos = scanned.sortedByDescending { it.dateAdded }

        // 3. Recently Played
        val recentlyPlayedVideos = scanned.filter { video ->
            "scanned_${video.id}" in historyMap
        }.sortedByDescending { video ->
            historyMap["scanned_${video.id}"]?.watchedTimestamp ?: 0L
        }

        // 4. Favorites
        val favoriteVideos = scanned.filter { video ->
            "scanned_${video.id}" in favIds
        }

        // 5. Downloads
        val downloadVideos = scanned.filter { video ->
            video.path.contains("Download", ignoreCase = true) || video.path.contains("downloads", ignoreCase = true)
        }

        // 6. Camera Videos
        val cameraVideos = scanned.filter { video ->
            video.path.contains("DCIM", ignoreCase = true) || video.path.contains("Camera", ignoreCase = true)
        }

        // 7. Screen Recordings
        val screenRecordings = scanned.filter { video ->
            video.path.contains("ScreenRecorder", ignoreCase = true) ||
            video.path.contains("Screenrecords", ignoreCase = true) ||
            video.path.contains("ScreenRecording", ignoreCase = true) ||
            video.path.contains("screen", ignoreCase = true) && !video.path.contains("DCIM", ignoreCase = true)
        }

        // 8. WhatsApp Videos
        val whatsappVideos = scanned.filter { video ->
            video.path.contains("WhatsApp", ignoreCase = true)
        }

        // 9. Telegram Videos
        val telegramVideos = scanned.filter { video ->
            video.path.contains("Telegram", ignoreCase = true)
        }

        // 10. Movies (Duration > 45 mins)
        val movies = scanned.filter { video ->
            video.duration >= 45 * 60 * 1000 && 
            !video.path.contains("WhatsApp", ignoreCase = true) &&
            !video.path.contains("Telegram", ignoreCase = true)
        }

        // 11. TV Shows (15 - 45 mins or contains typical TV tags)
        val tvShows = scanned.filter { video ->
            val pathLower = video.path.lowercase()
            val titleLower = video.title.lowercase()
            val hasTvTags = pathLower.contains("season") || pathLower.contains("episode") || pathLower.contains("show") ||
                    titleLower.contains("s01") || titleLower.contains("s02") || titleLower.contains("e01") || titleLower.contains("e02") ||
                    titleLower.contains("ep.") || titleLower.contains("episode")
            
            (video.duration in (15 * 60 * 1000)..(45 * 60 * 1000 - 1)) || hasTvTags
        }

        // 12. Music Videos
        val musicVideos = scanned.filter { video ->
            val pathLower = video.path.lowercase()
            val titleLower = video.title.lowercase()
            video.duration < 8 * 60 * 1000 && (
                pathLower.contains("music") || pathLower.contains("song") || pathLower.contains("mv") ||
                titleLower.contains("music") || titleLower.contains("lyrics") || titleLower.contains("official video") ||
                titleLower.contains("clip") || titleLower.contains("mv")
            )
        }

        // 13. Short Videos (<5 min)
        val shortVideos = scanned.filter { video ->
            video.duration < 5 * 60 * 1000
        }

        // 14. Long Videos (>20 min)
        val longVideos = scanned.filter { video ->
            video.duration > 20 * 60 * 1000
        }

        // 15. 4K Videos
        val fourKVideos = scanned.filter { video ->
            maxOf(video.width, video.height) >= 3840
        }

        // 16. HD Videos
        val hdVideos = scanned.filter { video ->
            val maxDim = maxOf(video.width, video.height)
            maxDim >= 1280 && maxDim < 3840
        }

        listOf(
            SmartCollectionItem("continue_watching", "Continue Watching", Icons.Rounded.PlayCircle, continueWatchingVideos, description = "Resume your media where you left off"),
            SmartCollectionItem("recently_added", "Recently Added", Icons.Rounded.NewReleases, recentlyAddedVideos, description = "Fresh imports in your local library"),
            SmartCollectionItem("recently_played", "Recently Played", Icons.Rounded.History, recentlyPlayedVideos, description = "Your play history"),
            SmartCollectionItem("favorites", "Favorites", Icons.Rounded.Favorite, favoriteVideos, description = "Your curated list of top media"),
            SmartCollectionItem("downloads", "Downloads", Icons.Rounded.Download, downloadVideos, description = "Offline videos downloaded on device"),
            SmartCollectionItem("camera", "Camera Videos", Icons.Rounded.PhotoCamera, cameraVideos, description = "Recorded clips from your device camera"),
            SmartCollectionItem("screen_recordings", "Screen Recordings", Icons.Rounded.ScreenShare, screenRecordings, description = "Captured screen recording videos"),
            SmartCollectionItem("whatsapp", "WhatsApp Videos", Icons.Rounded.Forum, whatsappVideos, description = "Video media received from WhatsApp"),
            SmartCollectionItem("telegram", "Telegram Videos", Icons.Rounded.Send, telegramVideos, description = "Downloaded media from Telegram channels"),
            SmartCollectionItem("movies", "Movies", Icons.Rounded.Movie, movies, description = "Cinematic feature films (>45 mins)"),
            SmartCollectionItem("tv_shows", "TV Shows", Icons.Rounded.Tv, tvShows, description = "TV series, serials, and episodes"),
            SmartCollectionItem("music_videos", "Music Videos", Icons.Rounded.MusicNote, musicVideos, description = "Soundtracks and visual songs"),
            SmartCollectionItem("short_videos", "Short Videos (<5 min)", Icons.Rounded.HourglassTop, shortVideos, description = "Quick clips and bite-sized stories"),
            SmartCollectionItem("long_videos", "Long Videos (>20 min)", Icons.Rounded.HourglassBottom, longVideos, description = "Extended films, documentaries & shows"),
            SmartCollectionItem("four_k_videos", "4K Videos", Icons.Rounded.HighQuality, fourKVideos, description = "Ultra High Definition media (2160p)"),
            SmartCollectionItem("hd_videos", "HD Videos", Icons.Rounded.Hd, hdVideos, description = "High Definition content (720p/1080p)")
        )
    }.flowOn(Dispatchers.Default)
     .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Helper metrics for DYNAMIC HOME
    val lastPlayedVideo: StateFlow<ScannedVideo?> = smartCollections.map { collections ->
        collections.find { it.id == "recently_played" }?.videos?.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val favoriteCollection: StateFlow<SmartCollectionItem?> = smartCollections.combine(mediaRepository.favorites) { collections, favs ->
        if (favs.isEmpty()) null
        else {
            val favIds = favs.filter { it.isFavorite }.map { it.id }.toSet()
            collections.filter { it.id != "continue_watching" && it.id != "recently_added" && it.id != "recently_played" && it.id != "favorites" }
                .maxByOrNull { collection ->
                    collection.videos.count { "scanned_${it.id}" in favIds }
                }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val largestCollection: StateFlow<SmartCollectionItem?> = smartCollections.map { collections ->
        collections.filter { 
            it.id != "continue_watching" && it.id != "recently_added" && it.id != "recently_played" && it.id != "favorites" && it.videos.isNotEmpty()
        }.maxByOrNull { it.totalSize }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}

class SmartCollectionsViewModelFactory(
    private val application: Application,
    private val mediaRepository: MediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SmartCollectionsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SmartCollectionsViewModel(application, mediaRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
