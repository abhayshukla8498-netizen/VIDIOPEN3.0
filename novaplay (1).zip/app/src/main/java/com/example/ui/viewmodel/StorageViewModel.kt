package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScannedVideo
import com.example.data.database.AppDatabase
import com.example.data.model.RecycleBinEntity

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

data class StorageStats(
    val totalInternal: Long = 0,
    val freeInternal: Long = 0,
    val usedInternal: Long = 0,
    val totalSdCard: Long = 0,
    val freeSdCard: Long = 0,
    val usedSdCard: Long = 0,
    val sdCardAvailable: Boolean = false,
    val totalStorage: Long = 0,
    val freeStorage: Long = 0,
    val usedStorage: Long = 0
)

data class StorageInsights(
    val largestFolder: String = "None",
    val largestFolderSize: Long = 0L,
    val largestVideo: String = "None",
    val largestVideoSize: Long = 0L,
    val totalVideoCount: Int = 0,
    val totalVideoSize: Long = 0L,
    val averageVideoSize: Long = 0L
)

data class DuplicateGroup(
    val size: Long,
    val duration: Long,
    val videos: List<ScannedVideo>
)

sealed class DeletionItem {
    data class Video(val video: ScannedVideo) : DeletionItem()
    data class Folder(val path: String) : DeletionItem()
}

class StorageViewModel(application: Application) : AndroidViewModel(application) {

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _storageStats = MutableStateFlow(StorageStats())
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    private val _storageInsights = MutableStateFlow(StorageInsights())
    val storageInsights: StateFlow<StorageInsights> = _storageInsights.asStateFlow()

    private val _largeVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())
    val largeVideos: StateFlow<List<ScannedVideo>> = _largeVideos.asStateFlow()

    private val _duplicateGroups = MutableStateFlow<List<DuplicateGroup>>(emptyList())
    val duplicateGroups: StateFlow<List<DuplicateGroup>> = _duplicateGroups.asStateFlow()

    private val _emptyFolders = MutableStateFlow<List<String>>(emptyList())
    val emptyFolders: StateFlow<List<String>> = _emptyFolders.asStateFlow()

    // Undo management
    private val _pendingDeletion = MutableStateFlow<DeletionItem?>(null)
    val pendingDeletion: StateFlow<DeletionItem?> = _pendingDeletion.asStateFlow()

    private val _undoCountdown = MutableStateFlow(0)
    val undoCountdown: StateFlow<Int> = _undoCountdown.asStateFlow()

    private var activeDeletionJob: Job? = null
    private var allScannedVideos: List<ScannedVideo> = emptyList()

    init {
        refreshStorageStats()
    }

    fun refreshStorageStats() {
        viewModelScope.launch {
            _storageStats.value = calculateStorageStats()
        }
    }

    fun analyzeStorage(videos: List<ScannedVideo>) {
        allScannedVideos = videos
        viewModelScope.launch(Dispatchers.Default) {
            _isAnalyzing.value = true
            try {
                // 1. Storage Stats
                val stats = calculateStorageStats()
                _storageStats.value = stats

                // 2. Large Videos Filter (>= 500 MB) sorted by largest
                val largeFiles = videos.filter { it.size >= 500L * 1024 * 1024 }
                    .sortedByDescending { it.size }
                _largeVideos.value = largeFiles

                // 3. Duplicate Detection (Size, Duration, Name, Hash)
                val duplicates = findDuplicates(videos)
                _duplicateGroups.value = duplicates

                // 4. Empty Folder Detection
                val emptyDirs = scanForEmptyFolders()
                _emptyFolders.value = emptyDirs

                // 5. Insights Calculation
                val insights = calculateInsights(videos)
                _storageInsights.value = insights

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    private suspend fun calculateStorageStats(): StorageStats = withContext(Dispatchers.IO) {
        try {
            val internalPath = Environment.getDataDirectory()
            val internalStat = StatFs(internalPath.path)
            val blockSize = internalStat.blockSizeLong
            val totalBlocks = internalStat.blockCountLong
            val availableBlocks = internalStat.availableBlocksLong

            val totalInternal = totalBlocks * blockSize
            val freeInternal = availableBlocks * blockSize
            val usedInternal = totalInternal - freeInternal

            var totalSdCard = 0L
            var freeSdCard = 0L
            var usedSdCard = 0L
            var sdCardAvailable = false

            val externalDirs = getApplication<Application>().getExternalFilesDirs(null)
            if (externalDirs.size > 1 && externalDirs[1] != null) {
                val sdFile = externalDirs[1]
                try {
                    val sdStat = StatFs(sdFile.absolutePath)
                    val sdBlockSize = sdStat.blockSizeLong
                    val sdTotalBlocks = sdStat.blockCountLong
                    val sdAvailableBlocks = sdStat.availableBlocksLong

                    totalSdCard = sdTotalBlocks * sdBlockSize
                    freeSdCard = sdAvailableBlocks * sdBlockSize
                    usedSdCard = totalSdCard - freeSdCard
                    sdCardAvailable = true
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            StorageStats(
                totalInternal = totalInternal,
                freeInternal = freeInternal,
                usedInternal = usedInternal,
                totalSdCard = totalSdCard,
                freeSdCard = freeSdCard,
                usedSdCard = usedSdCard,
                sdCardAvailable = sdCardAvailable,
                totalStorage = totalInternal + totalSdCard,
                freeStorage = freeInternal + freeSdCard,
                usedStorage = usedInternal + usedSdCard
            )
        } catch (e: Exception) {
            e.printStackTrace()
            StorageStats()
        }
    }

    private suspend fun findDuplicates(videos: List<ScannedVideo>): List<DuplicateGroup> = withContext(Dispatchers.Default) {
        // Step 1: Pre-group by size and duration (potential candidates)
        val sizeDurationGroups = videos.groupBy { "${it.size}_${it.duration}" }
            .filter { it.value.size > 1 }

        val duplicatesList = mutableListOf<DuplicateGroup>()

        for ((_, groupVideos) in sizeDurationGroups) {
            // Step 2: Perform partial MD5 hashing (first 512KB) to confirm duplicates
            val hashedGroups = withContext(Dispatchers.IO) {
                groupVideos.groupBy { video ->
                    calculatePartialHash(video)
                }
            }

            for ((_, duplicateCandidates) in hashedGroups) {
                if (duplicateCandidates.size > 1) {
                    val first = duplicateCandidates.first()
                    duplicatesList.add(
                        DuplicateGroup(
                            size = first.size,
                            duration = first.duration,
                            videos = duplicateCandidates
                        )
                    )
                }
            }
        }

        duplicatesList.sortedByDescending { it.size * it.videos.size }
    }

    private fun calculatePartialHash(video: ScannedVideo): String {
        val buffer = ByteArray(512 * 1024) // 512 KB
        try {
            val uri = Uri.parse(video.uriString)
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { inputStream ->
                val bytesRead = inputStream.read(buffer)
                if (bytesRead > 0) {
                    val md = MessageDigest.getInstance("MD5")
                    md.update(buffer, 0, bytesRead)
                    val digest = md.digest()
                    return digest.joinToString("") { "%02x".format(it) }
                }
            }
        } catch (e: Exception) {
            // Fallback to filename/path hash if file is unreadable
        }
        return "fallback_${video.title.hashCode()}_${video.size}"
    }

    private suspend fun scanForEmptyFolders(): List<String> = withContext(Dispatchers.IO) {
        val emptyFoldersList = mutableListOf<String>()

        fun scanDir(dir: File) {
            if (!dir.exists() || !dir.isDirectory) return
            val name = dir.name
            // Skip hidden and system folders to prevent accidental system file deletion
            if (name.startsWith(".") || name.equals("Android", ignoreCase = true) || name.equals("LOST.DIR", ignoreCase = true)) {
                return
            }

            val files = dir.listFiles()
            if (files == null || files.isEmpty()) {
                emptyFoldersList.add(dir.absolutePath)
                return
            }

            var hasMedia = false
            var subDirsCount = 0

            for (file in files) {
                if (file.isDirectory) {
                    subDirsCount++
                    scanDir(file)
                } else {
                    val ext = file.extension.lowercase()
                    if (ext in listOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "mp3", "wav", "m4a", "ogg", "flac", "jpg", "jpeg", "png", "webp", "gif")) {
                        hasMedia = true
                    }
                }
            }

            // A folder containing no media files and no sub-directories with media is considered empty/unneeded
            if (!hasMedia && subDirsCount == 0) {
                emptyFoldersList.add(dir.absolutePath)
            }
        }

        try {
            val publicDirs = listOf(
                Environment.DIRECTORY_MOVIES,
                Environment.DIRECTORY_DOWNLOADS,
                Environment.DIRECTORY_DCIM,
                Environment.DIRECTORY_PICTURES,
                Environment.DIRECTORY_MUSIC,
                Environment.DIRECTORY_DOCUMENTS
            )
            for (dirName in publicDirs) {
                val dir = Environment.getExternalStoragePublicDirectory(dirName)
                if (dir.exists()) {
                    scanDir(dir)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        emptyFoldersList.distinct()
    }

    private fun calculateInsights(videos: List<ScannedVideo>): StorageInsights {
        if (videos.isEmpty()) return StorageInsights()

        val largestVideo = videos.maxByOrNull { it.size }
        val totalSize = videos.sumOf { it.size }
        val avgSize = if (videos.isNotEmpty()) totalSize / videos.size else 0L

        // Group videos by parent directory to find largest folder
        val folderSizes = videos.groupBy { File(it.path).parent ?: "Unknown" }
            .mapValues { entry -> entry.value.sumOf { it.size } }

        val largestFolderEntry = folderSizes.maxByOrNull { it.value }

        return StorageInsights(
            largestFolder = largestFolderEntry?.key?.let { File(it).name } ?: "None",
            largestFolderSize = largestFolderEntry?.value ?: 0L,
            largestVideo = largestVideo?.title ?: "None",
            largestVideoSize = largestVideo?.size ?: 0L,
            totalVideoCount = videos.size,
            totalVideoSize = totalSize,
            averageVideoSize = avgSize
        )
    }

    // --- SAFETY & DELETION METHODS WITH UNDO ---

    fun requestDeleteVideo(video: ScannedVideo) {
        cancelActiveDeletion()
        _pendingDeletion.value = DeletionItem.Video(video)
        startUndoTimer {
            performRealVideoDeletion(video)
        }
    }

    fun requestDeleteFolder(path: String) {
        cancelActiveDeletion()
        _pendingDeletion.value = DeletionItem.Folder(path)
        startUndoTimer {
            performRealFolderDeletion(path)
        }
    }

    fun undoDeletion() {
        cancelActiveDeletion()
        _pendingDeletion.value = null
        _undoCountdown.value = 0
    }

    private fun startUndoTimer(onComplete: suspend () -> Unit) {
        activeDeletionJob = viewModelScope.launch {
            _undoCountdown.value = 5
            while (_undoCountdown.value > 0) {
                delay(1000)
                _undoCountdown.value -= 1
            }
            onComplete()
            _pendingDeletion.value = null
            // Re-trigger analysis after file deletions
            analyzeStorage(allScannedVideos)
        }
    }

    private fun cancelActiveDeletion() {
        activeDeletionJob?.cancel()
        activeDeletionJob = null
    }

    private suspend fun performRealVideoDeletion(video: ScannedVideo) = withContext(Dispatchers.IO) {
        try {
            // Save to database's recycle bin
            val recycleBinDao = AppDatabase.getDatabase(getApplication()).recycleBinDao()
            recycleBinDao.insertDeletedVideo(
                RecycleBinEntity(
                    id = video.id.toString(),
                    title = video.title,
                    path = video.path,
                    duration = video.duration,
                    size = video.size,
                    dateAdded = video.dateAdded,
                    uriString = video.uriString,
                    thumbnailUrl = video.thumbnailUrl,
                    type = "SCANNED"
                )
            )

            // Update local memory list
            allScannedVideos = allScannedVideos.filter { it.id != video.id }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private suspend fun performRealFolderDeletion(path: String) = withContext(Dispatchers.IO) {
        try {
            val folder = File(path)
            if (folder.exists() && folder.isDirectory) {
                // Delete empty directory
                folder.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
